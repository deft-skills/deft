# DEFT: walkthrough of the study

This document follows the work in the order it was built: vision, metamodel,
models, generation, evaluation, website, paper and publication. Every step points to
the artifacts to open, explains what was decided and why, and ends with the reviews
you need to make. It lives in `paper/`, which is excluded from the repository.

How to read it:

- **Open**: files to read side by side (links open in VS Code).
- **Run**: commands to execute from the repository root. On Windows use
  `.venv\Scripts\python` and `.venv\Scripts\deft`; in Git Bash use `.venv/Scripts/...`.
- **Decision**: a design choice made during the work, with its rationale. Challenge it.
- **Review Rn**: something only you can confirm. Write your answer in the box or tell me.

At the end of each part, a short **Tell me** lists what I need from you before we close.

---

## Part 1. The vision

### 1.1 The problem, in one paragraph

The Agent Skills specification fixes `name` and `description` and leaves everything
else free: the body is unstructured and skills are unrelated. Practitioners therefore
reuse by copying (clones, forks) and compose by prose ("then use skill X").
Copies drift, and a pipeline that wires two incompatible skills only fails while an
agent runs it.

### 1.2 The two needs and the claim

- **Specialization**: one procedure, several variants (EARS, user stories, Volere).
- **Composition**: activities chained through artifacts, with contracts.
- **Claim**: the two must be checked *together*. A specialization may narrow its
  input type (an acceptance-test skill only accepts user stories). That breaks
  substitutability, so whether a workflow is valid depends on which specializations
  it binds. DEFT accepts the narrowing in the hierarchy and checks it at binding time.

This last point is the intellectual core of the paper. Everything else
(constraints C1–C2, Fig. 2b, the 4/16 binding result, the discussion) supports it.

**Open**: [main.tex, Introduction](main.tex) (lines 77–88) and
[main.before-revision.tex](main.before-revision.tex) to compare with your draft.

**Decision: title.** "Agentic Skills" became "Agent Skills", the name of the standard.
Your alternative titles are still commented in the original file.

> **Review R4.a (title).** Keep "DEFT: a Metamodel for Agent Skills"? Alternatives:
> "DEFT: Specializing and Composing Agent Skills", "Agent Skills as Software Artifacts: A Metamodel".
>
> Your answer: DEFT: a Metamodel for Agent Skills

> **Review R4.b (claim).** Can you state the claim of 1.2 in your own words, in two
> sentences, as you would at the start of the talk? If you are not convinced by it,
> stop here and tell me: everything else depends on it.
> 
> Your answer: The vision of DEFT is to constrain and guide two dimensions for skill design. The first is specialization, supporting different levels of abstractions of a given skill, with inheritance and reuse at its core. The second one is composition, supporting workflow design, a common practice in the field. The two are combined in the sense that composition and specialization together impose preconditions and postconditions based on typed specialization, which is key (e.g., a performance test requires quality requirements).
>
> **Feedback.** The first two sentences are right. The third mixes two mechanisms that the
> paper keeps apart, and a reviewer may probe exactly this:
>
> - **Types (decidable, C1–C2).** The link between the dimensions is *input narrowing*:
>   the abstract `generate-tests` accepts any `Requirement`; its specialization
>   `performance-tests` accepts only `MeasurableQualityRequirement`. So a workflow that is
>   valid with `volere` upstream becomes invalid with `iso25010` upstream, although both
>   are quality requirements. That is the precise version of your example.
> - **Contracts (pre/postconditions, C5).** Natural language, not decided, listed as
>   review obligations. They also accumulate along the hierarchy, but they are not what
>   makes the two dimensions inseparable.
>
> Suggested version for the talk: *"Skills need specialization, one procedure with
> variants, and composition, workflows that exchange artifacts. The two cannot be checked
> separately, because a variant may accept a narrower input than its parent, so whether a
> workflow is valid depends on which variants it binds; DEFT accepts the narrowing in the
> hierarchy and checks it where the variant is bound."*

---

## Part 2. Designing the metamodel

### 2.1 Where the metamodel lives

The same metamodel exists in four forms. The Python one is authoritative because it
is the one that runs:

| Form | File | Used for |
|---|---|---|
| Python classes | [deft/model.py](../deft/model.py) | Everything executable |
| Ecore | [metamodel/deft.ecore](../metamodel/deft.ecore) | MDE audience, EMF tooling |
| OCL invariants | [metamodel/deft.ocl](../metamodel/deft.ocl) | The constraints, in OCL |
| Diagrams | [deft-specialization.puml](../metamodel/deft-specialization.puml), [deft-composition.puml](../metamodel/deft-composition.puml), Mermaid in [guides/metamodel.md](../guides/metamodel.md), [figures/metamodel.tex](figures/metamodel.tex) | Repository, docs/site, paper Fig. 1 |

**Open** [deft/model.py](../deft/model.py) and the rendered diagram
[deft-specialization.png](../metamodel/deft-specialization.png) and [deft-composition.png](../metamodel/deft-composition.png) side by side.

### 2.2 Specialization package

| Concept | Class | Notes |
|---|---|---|
| Skill | `Skill` ([model.py:135](../deft/model.py#L135)) | `parent` (0..1), `abstract`, `pre`/`post`, `metadata`, `origin`, `resources` |
| Section | `Section` ([model.py:85](../deft/model.py#L85)) | kind `fixed` / `abstract` / `hook` (template method); optional `source` file |
| Refinement | `Refinement` ([model.py:94](../deft/model.py#L94)) | `implements` / `overrides` / `extends` + target section name; optional `source` |
| Parameter | `Parameter` ([model.py:102](../deft/model.py#L102)) | direction, type, multiplicity `[lower..upper]` (`MANY = -1` is `*`): how many artifacts it carries; `lower = 0` makes it optional |
| Artifact type | `ArtifactType`, `Property` ([model.py:66](../deft/model.py#L66)) | own hierarchy; property multiplicity = how many values a field has (`fitCriterion [1]`, `metric [0..1]`) |
| Resource | `Resource` ([model.py:116](../deft/model.py#L116)) | `path`, `kind` (`ResourceKind`: script / reference / asset, the spec's `scripts/`, `references/`, `assets/`), `source` |
| Origin | `Origin` ([model.py:123](../deft/model.py#L123)) | repo, path, commit, licence, `mode` (`OriginMode`: adapted / imported). No origin = authored from scratch |

Why `Origin` is in the metamodel although it is not one of the two dimensions: the
generator needs it to bundle upstream licences (MIT/Apache attribution), it is the
declared supply chain (SkillBOM argument), and `imported` (verbatim, refresh by bumping
the commit) versus `adapted` (rewritten, needs a person when upstream changes) decides how
a skill is maintained.

**Resolution** is in [deft/resolve.py](../deft/resolve.py): walk from the root to the
skill, take the root's sections, and apply each descendant's refinements in order,
recording a `Contribution(skill, action)` for every change. That record is what makes
provenance possible.

Two additions beyond your draft, both needed by the evidence:

- **Placeholders** (`{{name}}`, `{{meta.key}}`) let one fixed section serve a family
  whose copies differ only in names. Spec Kit needed this (Part 5).
- **Section content from files** (`source:`, `heading:`, `demote:` in
  [loader.py:110](../deft/loader.py#L110)) lets a model *reference* an upstream skill
  instead of copying it. TDD and debugging are imported this way.

**Decision: conditions are inherited and accumulate.** Descendants add pre- and
postconditions. Adding a precondition strengthens it, which is the same covariance as
input narrowing and is handled the same way (C5 at composition).

**Decision: single inheritance.** Mixins were requested by practitioners (#380) but
left out. The coverage table reports this honestly as "none".

### 2.3 The S constraints

**Open** [deft/check.py](../deft/check.py): `check_well_formed` (line 64) to `check_s4`
(line 152). The docstring at the top lists every code.

| Code | Rule | Where |
|---|---|---|
| WF | Dangling references (unknown parent, type, node, parameter); a resource lives in the folder of its kind; an `imported` origin and sections read from upstream files (`source:`) go together | [check.py:64](../deft/check.py#L64) |
| S1 | Acyclic, single parent | `check_s1` (single parent is also enforced by the loader) |
| S2 | Concrete implements every inherited abstract section | `check_s2` |
| S3 | Refinement targets an ancestor's section of the right kind; no refinement of fixed; no redeclaration | `check_s3` |
| S4 | Redeclared parameter keeps direction and narrows type; a property redeclared by a subtype only tightens its multiplicity | [check.py:152](../deft/check.py#L152) |

**Changes after your review of the metamodel** (questions on `ResourceKind`, `Origin.mode`,
multiplicities and control nodes):

- (a) `Origin.mode` is now the enum `OriginMode` in Python, as it already was in Ecore,
  with no `created` value (no origin means authored), and a WF check that `imported`
  matches the use of `source:`.
- (b) S4 also covers artifact properties: a subtype may only tighten an inherited
  multiplicity (for example, a `VolereRequirement` cannot redeclare `fitCriterion [0..1]`).
  The generator now uses the nearest declaration of a property.
- (c) WF check that a bundled resource lives under the folder of its kind.
- (d) Not done, by decision: there is no OR-join (`merge`). All joins are AND joins, which
  the running example never needs because the loop uses a repair edge. Not stated in the paper.

Each change has tests ([test_constraints.py](../tests/test_constraints.py), 30 tests in
total) and mutation operators in E2 (Part 5.3).

### 2.4 Composition package

| Concept | Class |
|---|---|
| Composite skill (is a Skill) | `CompositeSkill` ([model.py:203](../deft/model.py#L203)) |
| Skill node: `role` + optional `bind` | `SkillNode` ([model.py:160](../deft/model.py#L160)) |
| Control node: `ControlKind` enum, `decision` or `final` | `ControlNode` ([model.py:172](../deft/model.py#L172)) |
| Data edge between ports `node.param` (`self.x` = workflow parameter) | `DataEdge`, `Port` ([model.py:178](../deft/model.py#L178)) |
| Control edge: `sequence` / `invokes` / `repair`, guard, bound, `carries` | `ControlEdge` ([model.py:193](../deft/model.py#L193)) |

Why only `decision` and `final`: with dataflow semantics the start is the workflow's own
inputs (`self.request`), fork is one output feeding several nodes, and join is a node
waiting for all its inputs. Explicit start, fork and join nodes would restate the edges.
`final` stays because a guarded decision exit needs a target.

Decisions taken when challenging the illustrative PlantUML drafts in
[paper/example](example/):

1. **Dataflow semantics (your option a).** A node runs when its mandatory inputs exist.
   Control edges are only needed for decisions, invocation and repair. Fork and join
   disappeared from the metamodel.
2. **Repair carries an artifact.** In the draft, implementation was re-run without
   knowing what failed. Now `repair` can carry the debugging diagnosis to an optional
   input of the target.
3. **Invokes is a call.** The invoked node takes its inputs from the caller (C3) and
   cannot be reached in any other way (C4). In the draft, `implement-persistence` was
   floating in the graph.
4. **Conditions moved to the core.** They belonged to `Skill`, not to the
   composition package.
5. **Persistence was dropped** in favour of TDD, which is invoked by plan execution in
   real practice (Superpowers).

### 2.5 The C constraints, and the C5 correction

**Open** [check.py:234–336](../deft/check.py#L234) (C1–C4) and
[check.py:365](../deft/check.py#L365) (`obligations`, C5).

- C1: binding is concrete and conforms to the role.
- C2: every data edge (and repair payload) is type-safe *on the bound skills*, with
  compatible multiplicities. This is where the claim of 1.2 materializes.
- C3: mandatory inputs are fed (or come from the caller, for invoked nodes).
- C4: acyclic without repair edges; repair edges bounded; invoked node only via its caller.
- **C5 changed.** Your draft said "for every edge m→n, post(m) entails pre(n)". That
  cannot hold in general: a node's preconditions concern *all* its inputs, so no single
  predecessor can entail them (try debug→implement: the plan does not come from
  debugging). The paper now says: the postconditions of all predecessors, plus the
  guards that reach n, jointly entail pre(n), with the workflow's preconditions taken
  as assumptions.

> **Review R4.c (metamodel).** Do you accept these decisions: dataflow semantics,
> repair carrying an artifact, inherited conditions that accumulate, single inheritance,
> and the C5 reformulation? Any of them you would present differently in the paper?
>
> Your answer:

**Run** (understand the checker by breaking things):

```bash
.venv/Scripts/deft check models
# Edit models/workflows/deliver-feature.yaml: functional node -> bind: ears, then:
.venv/Scripts/deft check models      # one C2 violation, EARSRequirement vs UserStory
# Revert, then in models/skills/requirements.yaml give 'volere' a refinement
#   - {kind: overrides, target: elicit, content: x}
.venv/Scripts/deft check models      # S3: overrides targets fixed section
# Revert both edits.
```

### Tell me (Part 2)

Answers to R4.b and R4.c, and anything in the metamodel you do not understand or disagree with.

---

## Part 3. Instantiating the models (running example)

### 3.1 Choosing the example

You were unsure whether the original example was strong enough. Two changes made it so:

- It follows the **spec-driven process** practitioners use (Spec Kit, Superpowers):
  specify → plan → implement test-first → verify → repair.
- It **reuses public skills** instead of inventing them, which reduces the bias of an
  author-designed example and grounds the paper in practice.

**Open** [README.md, Running example](../README.md) for the table of families and sources.

### 3.2 Pinned upstream material

**Open** [upstream/UPSTREAM.yaml](../upstream/UPSTREAM.yaml) and [NOTICE](../NOTICE).

| Library | Commit | Licence | Used for |
|---|---|---|---|
| github/spec-kit | b9e08bf | MIT | specify, clarify, plan, tasks (adapted); E1 refactoring |
| obra/superpowers | 8ca22db | MIT | writing-plans, executing-plans, subagent-driven-development (adapted); TDD, systematic-debugging (imported) |
| anthropics/skills | 683bc88 | Apache-2.0 | webapp-testing (adapted, plus helper script) |

Anthropic's document skills (docx, pdf, ...) were excluded: they are source-available,
not open source, and cannot go into a GPL-3 package. MIT and Apache-2.0 are compatible
with GPL-3. The generator copies the upstream licence next to every skill that derives
from it.

### 3.3 Artifact types

**Open** [models/types/artifacts.yaml](../models/types/artifacts.yaml).

The key design is in the quality branch:

```
QualityRequirement
├── MeasurableQualityRequirement   fitCriterion [1]   (abstract)
│   └── VolereRequirement
└── ISO25010Requirement            metric [0..1]
```

Volere is measurable *by type*, ISO/IEC 25010 is not. That is why `iso25010` cannot
feed `performance-tests` (C2), and why the `quantify-quality` adapter turns ISO
requirements into Volere cards.

### 3.4 The skill families

For each family, open the model and its upstream source side by side. What you are
reviewing is my adaptation of upstream text: condensed, restructured into sections,
and written in plain technical English.

| Family | Model | Upstream to compare with | What was done |
|---|---|---|---|
| Requirements | [requirements.yaml](../models/skills/requirements.yaml) | [specify.md](../upstream/spec-kit/templates/commands/specify.md), [clarify.md](../upstream/spec-kit/templates/commands/clarify.md) | Elicitation and clarification became fixed sections, validation a hook, the structure of requirements abstract. The four notations are authored from the RE literature (QUS, EARS patterns, Volere snow card, ISO/IEC 25010:2023 characteristics). |
| Planning | [planning.yaml](../models/skills/planning.yaml) | [plan.md](../upstream/spec-kit/templates/commands/plan.md), [tasks.md](../upstream/spec-kit/templates/commands/tasks.md), [writing-plans](../upstream/superpowers/skills/writing-plans/SKILL.md) | One concrete skill merging Spec Kit's design phases with Superpowers' task format (files, interfaces, covers, RED-GREEN steps). |
| Implementation | [implementation.yaml](../models/skills/implementation.yaml) | [executing-plans](../upstream/superpowers/skills/executing-plans/SKILL.md), [subagent-driven-development](../upstream/superpowers/skills/subagent-driven-development/SKILL.md), [test-driven-development](../upstream/superpowers/skills/test-driven-development/SKILL.md) | The principles both executors repeat (rulings, stop conditions, ledger, completion contract) moved into fixed sections of `execute-plan`; each executor implements only the task loop. TDD is imported verbatim. |
| Verification | [verification.yaml](../models/skills/verification.yaml) | [webapp-testing](../upstream/anthropics-skills/skills/webapp-testing/SKILL.md) | `generate-tests` (oracle and write abstract; trace and run fixed); `acceptance-tests` narrows the input to UserStory; `performance-tests` narrows it to MeasurableQualityRequirement; the Playwright variant adapts webapp-testing and bundles its script. |
| Support | [debugging.yaml](../models/skills/debugging.yaml) | [systematic-debugging](../upstream/superpowers/skills/systematic-debugging/SKILL.md) | Debugging imported verbatim; `quantify-quality` authored (adapter). |

> **Review R1 (adapted content).** For each family: is the content correct for an RE/SE
> expert, faithful to the upstream intent, and something you would sign? Pay special
> attention to the four requirement notations (your field) and to the execute-plan
> refactoring (it is the evidence for "fork and adapt").
>
> | Family | OK / changes needed |
> |---|---|
> | Requirements | |
> | Planning | |
> | Implementation | |
> | Verification | |
> | Support | |

### 3.5 The workflows

**Open** [deliver-feature.yaml](../models/workflows/deliver-feature.yaml) with its
rendered graph [example-deliver-feature.png](../metamodel/example-deliver-feature.png),
then [deliver-feature-iso.yaml](../models/workflows/deliver-feature-iso.yaml).

Read the YAML in three blocks: `nodes` (role, bind), `data` (ports), and `control`
(invokes TDD, the decision exits with guards, repair with bound 3 carrying the diagnosis).
The ISO variant swaps three bindings and inserts `quantify` between `quality` and the
consumers of quality requirements.

**Run:**

```bash
.venv/Scripts/deft diagram models --workflow deliver-feature   # PlantUML of the graph
.venv/Scripts/deft obligations models --workflow deliver-feature
```

### 3.6 The contract review (C5)

Listing the obligations of `deliver-feature` exposed three gaps in the first version of
the models. All three were fixed, and the history is recorded in
[review.yaml](../experiments/c5_contracts/review.yaml):

1. Acceptance tests require the *existing* tests to pass; plan execution only
   guaranteed the task's own tests. **Fix**: an execute-plan postcondition on the full suite.
2. Performance tests require a production-like environment that nothing provided.
   **Fix**: a workflow precondition (an assumption for every step).
3. The workflow promises a feature branch that no postcondition ensured. **Fix**: an
   execute-plan postcondition.

> **Review R3 (C5 review).** I did this review; the paper says "We reviewed". Read the
> 8 obligations in [c5_obligations.md](../experiments/results/c5_obligations.md) and
> confirm the 3 gaps and that the other 5 hold. If you or a co-author disagree with any
> verdict, the paper text changes.
>
> Your answer:

### Tell me (Part 3)

The R1 table and R3. Note: the example has no unit-test node any more; TDD inside
implementation covers unit tests. Do you agree?

---

## Part 4. Skill generation

### 4.1 From model to SKILL.md

**Open** [deft/generate.py](../deft/generate.py): `render_skill` (line 123) for skills,
`render_workflow` (line 173) for composite skills, `generate` (line 274) for the folders.

**Run:**

```bash
.venv/Scripts/deft generate models --out skills
```

Then open two outputs side by side:

- [skills/volere/SKILL.md](../skills/volere/SKILL.md), a three-level specialization.
- [skills/deliver-feature/SKILL.md](../skills/deliver-feature/SKILL.md), the workflow.

Anatomy of a generated skill:

| Part | Content | Why |
|---|---|---|
| Frontmatter | `name`, `description`, `license`, `metadata.deft-*` (lineage, inputs, outputs, origin, requires) | Only the fields the specification allows; DEFT data goes in `metadata` |
| Inputs and outputs | Parameters with the fields of their artifact types | The agent knows what to produce |
| Before you start / Done when | Inherited and own conditions | Contracts visible to the agent |
| Sections | Resolved content, with `<!-- deft: ... -->` provenance | Traceability; omit with `--no-provenance` |
| Licence files | `LICENSE-spec-kit.txt`, ... | MIT/Apache attribution |

Workflows list their steps in an order compatible with all edges
(`topological_steps`), and name each skill to load, where each input comes from,
invocations, the decision and the repair loop with its bound.

**Decision: YAML for authoring, SKILL.md for agents.** You asked about this. The
frontmatter cannot hold typed structure, and partial skills (abstract, or children
holding only refinements) are not valid skills. A Markdown front end for authors is in
Future Plans.

### 4.2 Validation and tests

**Run:**

```bash
.venv/Scripts/python -m pytest -q         # 30 tests: every constraint + generator
```

**Open** [tests/test_constraints.py](../tests/test_constraints.py) (one positive and one
negative case per constraint, plus the two seeded faults of the running example) and
[tests/test_generate.py](../tests/test_generate.py) (`skills-ref` on every generated
skill, licences, step order).

> **Review R1.b (generated output).** Read `skills/user-stories/SKILL.md` as if you were
> the agent. Is it usable? Anything confusing in the generated wording ("Inputs and
> outputs", "Before you start", "Done when")?
>
> Your answer:

---

## Part 5. Evaluation

The paper's research question is answered with two formative criteria (FEDS):
**expressiveness** (E1) and **checkability** (E2), plus a description of the generated
output (E3) and the C5 review. Everything is reproducible:

```bash
.venv/Scripts/python experiments/run_all.py
```

The results are in [experiments/results/](../experiments/results/), summarized in
[summary.md](../experiments/results/summary.md). The method is described in
[experiments/README.md](../experiments/README.md).

### 5.1 E1 Expressiveness: survey of conventions

**Open** [survey.py](../experiments/e1_expressiveness/survey.py) and
[mapping.yaml](../experiments/e1_expressiveness/mapping.yaml).

- Counted automatically in the pinned libraries: Spec Kit has 10 commands and 8
  frontmatter handoffs; entry checks appear in all 10 and completion checklists in 5.
  Superpowers has 15 skills, 20 prose references between skills, and 8 embedded DOT
  graphs in 6 skills.
- The mapping table (14 conventions) is a **judgement**: 9 full, 3 partial, 2 none. It
  is Table I in the paper.

> **Review R2 (coverage judgements).** Go through the 14 rows of
> [mapping.yaml](../experiments/e1_expressiveness/mapping.yaml). Do you agree with each
> full/partial/none? The borderline ones are *deny* (partial: empty hook, but fixed
> sections cannot be removed), *run-time skill choice* (partial: needs a decision node)
> and *embedded process graph* (partial: DEFT graphs connect skills, not steps).
>
> Your answer:

### 5.2 E1 Expressiveness: Spec Kit as one DEFT family

This is the strongest expressiveness evidence. **Open**
[refactor_speckit.py](../experiments/e1_expressiveness/refactor_speckit.py) and its
output [speckit-model/skills/spec-kit.yaml](../experiments/e1_expressiveness/speckit-model/skills/spec-kit.yaml).

The algorithm, fully automatic:

1. Split the 10 commands into `##` sections.
2. Sections whose heading recurs and whose non-blank lines are at least 80% similar
   become **ancestor sections**: lines identical in every copy stay fixed text; lines
   that vary become `{{meta.<slot>}}` placeholders filled by each command's metadata.
3. A copy that does not fit the majority template (a different number of lines)
   **overrides** the section, which then has to be a hook. This is how drift shows up.
4. Commands that share a recurring section set get an intermediate abstract ancestor.
5. The script resolves every command and compares it with the upstream text.

Results: 4 recurring sections (28 copies) became ancestor sections; the round trip is
identical for **10/10** commands; **1,410** lines are authored instead of **1,817** (22%
fewer); **converge**'s entry checks have drifted; the five pipeline commands (specify,
clarify, plan, tasks, implement) emerge as their own sub-family.

**Run** it alone and read the hierarchy it prints:

```bash
.venv/Scripts/python experiments/e1_expressiveness/refactor_speckit.py
```

### 5.3 E2 Checkability: mutation analysis

**Open** [mutate.py](../experiments/e2_checkability/mutate.py) (the operator list is at
line 262). There are 19 operators, each seeding one fault of one constraint at every
applicable location of the running example: 16 for S1–S4 and C1–C4, plus three added
with the metamodel changes (widen a property multiplicity, mismatch a resource kind,
flip an origin mode). Results: 281 mutants (S1–S4: 19, 10, 103, 41; C1–C4: 25, 25, 19,
27; WF: 12), all detected under the targeted constraint, 235 only under it, no
violations on the original models.

The honesty caveat is in the paper's threats to validity: operators are derived from
the constraints, so this shows the *completeness* of the checker for each constraint,
not real-world fault frequency.

**Open** [e2_mutation.json](../experiments/results/e2_mutation.json) and search for a
mutant reported under several codes, to see the knock-on effects.

### 5.4 E2 Checkability: binding space

**Open** [configurations.py](../experiments/e2_checkability/configurations.py). Every
variation point is bound to every concrete specialization (functional notation ×
quality notation × executor × acceptance style = 16 configurations). In each workflow
**4/16** are well formed, and all rejections are C2. This number backs the Discussion
sentence "three quarters of the configurations are ill-typed".

### 5.5 E3 Generation

**Open** [measure.py](../experiments/e3_generation/measure.py). There are 198 authored
instruction lines and 457 imported; 15 generated skills totalling 1,245 lines; 134
distinct lines recur across skills (282 extra copies); 15/15 pass `skills-ref`.

### 5.6 Optional: E4 agent run

**Open** [examples/account-service/](../examples/account-service/) (moved from `experiments/`; it is a usage example of DEFT). There is a small
FastAPI account service without password reset, the feature request, `prepare.py`
(installs the generated skills into a fresh copy) and `inspect_run.py` (artifacts,
traceability matrix, commits, verdict). It is not in the paper's results; it is Future
Plans and good material for the talk.

> **Decision for you (E4).** Do you want to run it once before the deadline? It does not
> change the paper, but a real trace (requirements file, plan, ledger, tests,
> traceability) would make the demo and the presentation concrete. I can guide it.

### Tell me (Part 5)

R2, and whether we do E4.

---

## Part 6. The website

**Run:**

```bash
.venv/Scripts/python site/build.py
.venv/Scripts/python -m http.server -d _site 8000     # open http://localhost:8000
```

**Open** [site/build.py](../site/build.py) (one function per page),
[site/static/style.css](../site/static/style.css) and [site/site.yaml](../site/site.yaml).

The site is DEFT's long-term home, not a report of the paper: it shows no evaluation
results. Everything comes from the repository, so it never disagrees with it:

- **Guides** are the Markdown files of [guides/](../guides/) and the example's README, rendered
  as they are (links rewritten to site pages or to repository files through
  `source_url` in [site.yaml](../site/site.yaml)). Edit the docs, never the site.
- **Catalogue**: one page per skill (resolved sections with provenance, the generated
  SKILL.md, the model), the artifact types, and one page per workflow (graph, bindings,
  the alternative bindings computed live by the checker, the contracts to review).
- **About**: contents of the repository, contributing, the use of generative AI (taken
  from the README section, so there is a single text), licence.

The look follows agentskills.io: monochrome, Inter and JetBrains Mono, light and dark
modes. Diagrams in the guides are Mermaid, which also renders on GitHub.

**Publishing.** `python site/build.py` writes the site to `docs/`, which is committed and
served by GitHub Pages from branch `main`, folder `/docs`. Committing the built site is
what lets the anonymous mirror serve it too (`https://anonymous.4open.science/w/deft-F7FE/`):
the mirror serves committed files from the Pages folder of the same branch. CI fails if
`docs/` is out of date. During the review, `site/site.yaml` points the repository links to
the anonymized mirror; switch them to GitHub at camera-ready and rebuild.

> **Review R5 (wording).** Browse the overview, the guides, one skill page, the workflow
> page and the About page. Note any wording you want changed. The same applies to
> [README.md](../README.md) and [guides/](../guides/).
>
> Your notes:

---

## Part 7. The paper

### 7.1 How it was built

**Open** [main.tex](main.tex), [figures/metamodel.tex](figures/metamodel.tex),
[figures/example.tex](figures/example.tex) and [main.pdf](main.pdf).

- Both figures are TikZ (no external images): Fig. 1 is the metamodel, Fig. 2 is
  (a) the hierarchies and (b) the workflow annotated with the C2 checks.
- The page count was verified with pdfLaTeX and Times (TinyTeX): **4 pages + 1 of
  references**, with a few lines to spare on page 4. Compile it once in your own
  setup (Overleaf) to confirm. Packages: tikz, dirtree, tcolorbox, fontawesome5,
  enumitem, booktabs.
- The only warning is an overfull box in the placeholder author block, which comes
  from the template.

### 7.2 Section by section, against your draft

| Section | What changed | Why |
|---|---|---|
| Abstract | Results added (12/14, 10/10 and 20% fewer tokens, 281/281) | NIER asks for promising initial results |
| Introduction | Statistics compressed; contributions name the implementation and the replication package | Space; contributions match the content |
| Background | Two paragraphs; Superpowers added next to Spec Kit | Space; second workflow library |
| III-A Method | Shortened; RQ and the two FEDS criteria kept | Space |
| III-B Metamodel | Covariance paragraph restored; dataflow semantics; repair with artifact; C5 reformulated; S4 extended to property multiplicities | Soundness |
| III-C Implementation | New; mentions the well-formedness checks | Was a TODO |
| IV-A Running example | Box updated (skills and sources) | New example |
| IV-B Demonstration | Specialization, composition, C5 gaps, generation | Was TODOs |
| IV-C Evaluation | Table I extended to 14 conventions; Spec Kit refactoring; mutation; binding space | Was TODOs |
| V Discussion | Interdependence argued with the 4/16 result; artifacts, sustainability, generalization; full threats | Was TODOs |
| VI Future Plans | Design, demonstration, evaluation; ASD-STE100 as a variable; TAM | NIER requires this section |
| VII Related Work | Compressed into one paragraph, same works | Space |
| VIII Conclusions, Data Availability | Written | Was empty |

### 7.3 Claim by evidence

Use this table to defend every number:

| Claim in the paper | Evidence |
|---|---|
| 12 of 14 conventions (9 full, 3 partial) | `mapping.yaml`, `e1_survey.json` → `coverage` |
| 8 handoffs, 20 prose references, 8 graphs | `e1_survey.json` |
| 4 sections, 28 copies, 10/10 round trip, 23.6k vs 29.6k tokens (20% fewer; 1,410 vs 1,817 lines), 1 drift | `e1_speckit_refactoring.json` (tokens: tiktoken `o200k_base`) |
| 19 operators, 281 mutants, per-constraint counts (incl. WF 12), 235 exclusive | `e2_mutation.json` |
| 4 of 16 configurations, 12 C2 rejections | `e2_configurations.json` |
| 2.7k authored and 4.5k imported tokens, 15 skills (13.8k tokens), 3.6k repeated tokens (26%), 15/15 skills-ref | `e3_generation.json` |
| 8 obligations, 3 gaps | `c5_obligations.md`, `review.yaml` |
| 21 skills (6 abstract), 6 adapt or import 10 upstream skills | `models/`, `UPSTREAM.yaml` |
| 1.3k lines, about 60 ms | `deft/` (1,273 non-blank, non-comment lines); timing of load+check |

### 7.4 Bibliography changes

- Added: Superpowers, anthropics/skills, Jia and Harman (mutation testing), Davis (TAM),
  ASD STEMG white paper, SimpleEnglish, Kuhn (CNL survey, currently not cited).
- No longer cited, so they drop out of the references: Li2026SingleAgent,
  Engstrom2020DSR, He2025MASSE, Chatlatanagulchai2026AgentREADMEs, Liang2025Prompts,
  Jiang2026SoK, Liu2025Patterns.
- Author lists of four or more names were cut to "et al." to fit one page. The
  original file is [ref.before-revision.bib](ref.before-revision.bib).

> **Review R4.d (text).** Read [main.pdf](main.pdf) end to end. Mark anything that is not
> your voice, any claim you would soften, and whether any dropped citation must come back.
>
> **Review R7 (bibliography).** Check the new entries, especially the titles of
> Superpowers and anthropics/skills (repository titles, corrected to their README
> wording) and the STE white paper (2026, ASD STEMG).
>
> **Review R6 (generative-AI disclosure).** ICSE 2027 follows the ACM authorship
> policy, which asks authors to disclose generative-AI use in the paper. Keeping the
> replication package free of traces is a separate matter. This is your decision; if you
> disclose, it is usually one sentence in the acknowledgements of the camera-ready.
>
> Your answers:

---

## Part 8. Publication

### 8.1 Anonymity check

The `paper/` folder is excluded through `.git/info/exclude`, so even the existence of
the folder does not reach the repository. The repo-local git identity is
`Anonymous <anonymous@example.org>`. Nothing has been committed yet.

**Run:**

```bash
git config user.name; git config user.email          # Anonymous / anonymous@example.org
git status --short --ignored | grep paper             # "!! paper/"
```

### 8.2 Steps to complete

| Step | Command / action | Review |
|---|---|---|
| 1. Replace the placeholder URL | `https://anonymous.4open.science/r/DEFT` appears in `main.tex` (2×) and `site/site.yaml` (the site's pages read it from there); rebuild the site afterwards | R8 |
| 2. First commit | `git add -A && git commit -m "DEFT replication package"` (check `git log --format='%an %ae'`) | R9 |
| 3. Push | To a repository under an account that does not reveal you | R9 |
| 4. Pages | Settings → Pages → Deploy from a branch: `main`, folder `/docs` (the built site is committed there; CI checks it is up to date) | R9 |
| 5. Anonymous mirror | anonymous.4open.science → anonymize the repository → put the link in the paper | R8 |
| 6. Final compile | Upload `main.tex`, `ref.bib`, `figures/` to Overleaf; check 4 + 1 pages | R10 |
| 7. Submit | HotCRP, before 23 Oct 2026 AoE | R10 |

> **Tell me (Part 8).** Which account or organisation will host the repository and the
> Pages site? You commit and push yourself.

---

## Part 9. Closing the work (round 2)

What changed after your second review, and the steps left. Do them in order; each step
ends with what I need from you.

### What changed

| Your point | Change |
|---|---|
| 1. The site is DEFT's home, not the paper's | Evaluation page and numbers removed; guides render [guides/](../guides/) (renamed from `docs/`, which now holds the built site); workflow pages compute alternative bindings live; new About page |
| 2. README as a tutorial | [README.md](../README.md) rewritten: get started, then six steps (metamodel, write a model with a worked Planguage exercise, validate, generate, use with an agent, browse); new [docs/README.md](../docs/README.md), [guides/metamodel.md](../guides/metamodel.md), [docs/using-skills.md](../docs/using-skills.md), [docs/cli.md](../docs/cli.md) |
| 3. Run E4 | Moved to [examples/account-service/](../examples/account-service/) with a README tutorial; `prepare.py` and `check_run.py` improved; the ISO workflow now binds Gherkin acceptance tests (the service has no UI). A run folder is ready at `../deft-run` |
| 4. Figures | `deft.puml` replaced by [deft-specialization](../metamodel/deft-specialization.png) and [deft-composition](../metamodel/deft-composition.png) (cleaner style, no constraint notes, references as typed attributes); the generated diagrams use the same style and omit section contents; the guides use Mermaid |
| 5. Transparency on AI use | Draft section in the README (also shown on the About page); scope to confirm in step 5 |

### Step 1. Follow the README as a newcomer

Open [README.md](../README.md) and do "Get started" and "Learn DEFT" steps 1 to 4,
including the Planguage exercise (I verified it: Planguage passes, ISO/IEC 25010 fails
with C2). Undo the exercise edits afterwards (`git checkout models` once committed, or
by hand now).

> **Tell me:** where did you hesitate, what was unclear or missing?

### Step 2. Browse the site

```bash
.venv/Scripts/python site/build.py
.venv/Scripts/python -m http.server -d _site 8000
```

> **Tell me (R5):** wording you want changed on the overview, quickstart, guides, a skill
> page, a workflow page, About.

### Step 3. Judge the diagrams

Open [deft-specialization.png](../metamodel/deft-specialization.png),
[deft-composition.png](../metamodel/deft-composition.png),
[example-deliver-feature.png](../metamodel/example-deliver-feature.png) and
[example-library.png](../metamodel/example-library.png) (wide: one package per family).

> **Tell me (R11):** keep, adjust (what), or you will redraw them. If you redraw, keep the
> `.puml` names or tell me the new files so the docs point to them.

### Step 4. Run the example with an agent (E4)

The run folder `../deft-run` is ready: the system, 15 skills in `.claude/skills/`, a
virtual environment with the dependencies, and two commits. In a terminal:

```bash
cd ../deft-run
claude
```

Paste the content of `FEATURE-REQUEST.md` as the first message. Answer the
clarification questions (at most three), then let it run to the end. Keep the
terminal transcript (or `/export` it in Claude Code). Then, from the DEFT repository:

```bash
.venv/Scripts/python examples/account-service/check_run.py ../deft-run --json ../deft-run-report.json
```

What to watch while it runs: does it load `deliver-feature` and then the bound skills in
order, write `specs/<feature>/requirements.md` with US- and QR- ids, plan, work on a
feature branch with a `progress.md` ledger, invoke TDD per task, write Gherkin and Locust
tests, and debug/repair if something fails?

> **Tell me:** send me the report JSON and your observations (or tell me to read
> `../deft-run`). Then decide: (a) keep the run only as your evidence for the talk,
> (b) add a short summary of the run to `examples/account-service/` (for instance a
> `RUN.md` with the report and observations), or (c) also mention it in the paper. The
> paper is full, so (c) means a one-line Future Plans change at most.

### Step 5. Decide the statement on generative AI (R6)

The README now has a section "Use of generative AI" (also shown on the site's About
page). Its current text covers the models in `models/` and "other supporting material".
For accuracy, consider what was produced with the coding agent in this project: the YAML
models and the adaptation of upstream skills, but also the Python implementation of
`deft`, the experiment scripts, the website, the documentation, the figures, and edits to
the manuscript text. The metamodel concepts, the constraints and the research design are
yours. ACM's authorship policy asks for disclosure of generative-AI use in the paper as
well.

> **Tell me:** which scope to state (A: models and supporting material, as now;
> B: an explicit list as above), whether to name the tool, and where to put the sentence
> in the paper (Threats to validity is the natural place: it also says that the quality
> of the example skills is not what the study evaluates). I will then fit it within the
> 4 pages.

### Step 6. Commit and push (you)

```bash
git status --short --ignored | grep paper       # "!! paper/": stays out
git config user.name; git config user.email      # Anonymous identity for this repository
git add -A
git commit -m "DEFT: metamodel, tools, example library, docs and evaluation"
git log --format='%an <%ae>'                     # check the identity before pushing
git remote add origin <your anonymous repository>
git push -u origin main
```

Then set Pages to deploy from branch `main`, folder `/docs`, mirror the repository on
anonymous.4open.science, and replace the URL in `paper/main.tex` and `site/site.yaml`
(including `source_url`).

---

## Appendix A. Command cheat-sheet

```bash
deft check models                      # WF, S1-S4, C1-C4
deft resolve models <skill>            # resolved SKILL.md on stdout
deft generate models --out skills      # all concrete skills and executable workflows
deft obligations models                # C5 obligations
deft diagram models [--workflow W]     # PlantUML
python -m pytest -q                    # tests
python experiments/run_all.py          # all results + summary.md
python site/build.py                   # website into _site/
```

## Appendix B. Review checklist

- [ ] R1 Adapted content per family (Part 3.4) and generated wording (Part 4.2)
- [ ] R2 Coverage judgements (Part 5.1)
- [ ] R3 C5 review (Part 3.6)
- [ ] R4 Title, claim, metamodel decisions, text (Parts 1, 2, 7)
- [ ] R5 Site, README and docs wording (Part 6)
- [x] R6 Generative-AI disclosure: scope A (models + other supporting material), README + site About + paper Threats to validity
- [ ] R7 Bibliography entries (Part 7.4)
- [ ] R8 Anonymous URL everywhere (Part 8)
- [ ] R9 Commit, push, Pages (Part 8)
- [ ] R10 Overleaf compile and submission (Part 8)
